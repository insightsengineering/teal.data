ADSL <- data.frame(1, 2) # nolint

ADSL$x <- 2 # nolint
