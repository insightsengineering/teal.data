
# code ADSL ADTTE>
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
# <ADSL ADTTE code

# code ADTTE>
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
# <ADTTE code
